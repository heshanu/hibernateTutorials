For this lecture, to avoid any confusion, use only Hibernate 5.0.4 jar files while running the provided source-code, as the support for java.time package in Java 8 was provided only from Hibernate 5 onwards. 

The required Hibernate 5.0.4 jar files for the entire course could be downloaded from Lecture 10.
